/**
 * 
 */
/**
 * 
 */
module Job_Application_Tracking_System {
	requires java.desktop;
	requires java.sql;
}